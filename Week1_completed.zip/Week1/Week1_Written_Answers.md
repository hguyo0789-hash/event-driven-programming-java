# Week 1: Written Deliverables

**Student:** Halkano Guyo, 25ZAD110789

## Activity 1: Spot the Components

| # | System | Event Source | Event | Listener | Handler / Action |
|---|---|---|---|---|---|
| 1 | ATM | Keypad button | Button pressed | ATM software | Verify PIN |
| 2 | ATM | Card slot | Card inserted | Card reader | Read card data |
| 3 | ATM | Cash dispenser | Cash taken | Sensor | End transaction |
| 4 | Microwave oven | Start button | Start pressed | Control board | Turn on the magnetron and start the countdown |
| 5 | Microwave oven | Door switch | Door opened | Safety interlock | Stop heating immediately |
| 6 | Traffic light | Timer or vehicle sensor | Timer expires or car detected | Signal controller | Change the light phase |
| 7 | Video game | Game controller | Button pressed | Game engine input system | Make the character jump or move |
| 8 | Video game | Collision detector | Player hits enemy | Game logic | Reduce health and play a sound |
| 9 | Elevator | Floor button | Floor requested | Elevator controller | Add the floor to the queue and move the car |
| 10 | Elevator | Door sensor | Beam blocked | Door controller | Reopen the doors |
| 11 | Smartphone touchscreen | Screen | Tap or swipe | Touch driver and app | Open the app or scroll the list |
| 12 | Online shopping site | Add to cart button | Click | Page script | Add the item and update the cart count |
| 13 | Security alarm | Motion detector | Motion detected | Alarm controller | Sound the siren and notify the owner |

### Self-check
1. An event source is the component that generates an event, such as a button or a sensor. An event listener is the object that has registered interest in that source and is notified when the event happens.
2. Yes. One source can have many listeners. A single JButton can have one listener that updates a label and another that writes to a log, and both run when it is clicked.
3. Yes. One listener can serve many sources. One ActionListener can be attached to every digit button of a calculator and use the event's source to decide which digit to append.

## Activity 2: Event Loop Reflection

The event queue is the waiting line in which events such as clicks, key presses and timer ticks are stored in the order they arrive. The event loop is the process that repeatedly takes the next event from that queue and passes it to the handler registered for it. When I simulated this with cards, each event was processed one at a time, strictly in order. In the blocked round, the other cards had to wait while one handler took a long time, so in a real application the window would stop responding, repaint late or look as though it had crashed. The event loop should never be blocked because it is also responsible for painting the screen and reading input, so anything that holds it up freezes the whole interface. The fix is to move slow work into a background thread and return to the loop only to update the display.

**Round 3 questions.** (1) The other events stayed in the queue unprocessed until the slow handler finished. (2) The user would see a frozen, unresponsive window. (3) Run the long task on a worker thread and report back through the event loop.

## Activity 3: Procedural vs. Event-Driven

**Procedural calculator.** (1) The program asks for the first number, then the operator, then the second number, calculates, displays the result and ends. (2) An invalid operator prints "Invalid operator" and the program exits; non-numeric input at a number prompt throws an exception. (3) No, the program must be restarted. (4) The program controls the flow.

**Event-driven calculator.** (1) Yes, buttons can be clicked in any order. (2) The user can press C to clear and start again. (3) Yes, the window stays open for repeated calculations. (4) The user controls the flow. (5) There are 16 event handlers: ten digit buttons, four operator buttons, equals and clear. The startup runnable passed to `invokeLater` is a seventeenth piece of code that runs on the EDT but is not a listener.

| Aspect | Procedural | Event-Driven |
|---|---|---|
| Who controls the flow? | The program | The user |
| Can the user make mistakes and recover easily? | No, an error usually ends the run | Yes, the user can clear and retry |
| Can the user interact in any order? | No, the order is fixed | Yes |
| How many possible execution paths? | Few and predictable | Very many, depending on the user's actions |
| Code organization | One top-to-bottom sequence | Many small handlers, each for one event |
| User experience | Rigid, text prompts | Flexible and interactive |

**Reflection.** The main difference is who is in charge: a procedural program follows a fixed sequence that its author decided, while an event-driven program waits and reacts to whatever the user does. In the two calculators, the procedural one could do a single calculation and exit, but the event-driven one could be used again and again and let the user correct mistakes. For interactive applications I prefer the event-driven approach because it matches how people actually use software. It is better suited to graphical interfaces because a GUI contains many controls that can be used in any order, and handlers let each control be coded independently. The cost is more complex state to manage, as seen in the flags the calculator needed.

## Activity 6: Self-Assessment

1. An event is a signal that something happened, such as a button click or a key press.
2. An event source is the object that produces events, for example a JButton or a Timer.
3. An event listener is an object registered with a source to be told about its events, for example an ActionListener or a MouseListener.
4. An event handler is the code that runs in response, for example the body of actionPerformed or a lambda that updates a label.
5. Diagram: `Event source --(generates)--> Event --(queued, then dispatched)--> Listener --(calls)--> Handler`.
6. Procedural programming runs a fixed sequence chosen by the program; event-driven programming waits and runs code in response to events.
7. Its main advantage for GUIs is that the user can interact with any control in any order and the interface stays responsive.
8. I would choose procedural for a simple batch script or command-line tool that runs a fixed series of steps with no user interaction.
9. The event loop continuously takes events from the queue and dispatches each to its handler.
10. The event queue holds pending events in first-in, first-out order until the loop is ready for them.
11. Blocking it freezes painting and input handling, so the application appears hung.
12. The EDT, or Event Dispatch Thread, is the single thread on which Swing creates the GUI, handles events and repaints.
13. ATM, microwave oven, elevator, smartphone touchscreen and a traffic light controller.
14. For the ATM: source is the keypad, event is a key press, listener is the ATM software, handler is the PIN verification routine.
15. Because users expect applications to react instantly to many kinds of input, and the event-driven model lets programs respond to those inputs without polling or fixed sequences.

**Self-score:** 15 of 15, mastered Week 1 concepts.

### One-page summary
Week 1 introduced event-driven programming: a program defines what should happen when something occurs instead of running a fixed script. The key terms are the event, the source that generates it, the listener registered to receive it and the handler code that responds. Events wait in a queue and the event loop dispatches them one by one, which is why the loop must never be blocked; in Swing this loop runs on the Event Dispatch Thread. Comparing the procedural and event-driven calculators showed that control passes from the program to the user. The four bug exercises were the most useful practice: long work must go on a background thread, every control needs a registered listener, GUI updates from other threads must use `SwingUtilities.invokeLater`, and objects removed from the interface must also be removed from any list that references them. A question I still have is how the same ideas translate to JavaFX, which I expect to cover later in the course.
