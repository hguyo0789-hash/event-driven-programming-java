# Event-Driven System Design

## System Name: Smart Home Controller

---

## Part 1: Event Sources
1. Light switch (lights toggle) - generates turn-on and turn-off events
2. Security panel - generates arm and disarm events
3. Door sensor - generates door-opened and door-closed events
4. Thermostat control - generates temperature-changed events
5. System timer - generates scheduled events such as an evening lights routine

---

## Part 2: Events

| Event Name | Source | Description |
|---|---|---|
| LightsToggled | Light switch | The user switches the lights on or off |
| SecurityArmed / SecurityDisarmed | Security panel | The user arms or disarms the alarm |
| DoorOpened | Door sensor | The door contact opens |
| TemperatureChanged | Thermostat | The user or a sensor changes the target temperature |
| TimerFired | System timer | A scheduled time is reached |

---

## Part 3: Event Handlers

| Event | Handler Action |
|---|---|
| LightsToggled | Update the toggle text, change the status line, and write the change to the event log |
| SecurityArmed / SecurityDisarmed | Update the security state and log it |
| DoorOpened | Log the sensor trigger and, if the system is armed, raise an alarm message |
| TemperatureChanged | Update the displayed target temperature and log the change |
| TimerFired | Switch the lights on and log that the routine ran |

---

## Part 4: Event Flow Diagram

```
User action / sensor
        |
        v
  Event source (button, sensor, timer)
        |
        v
  Event object (ActionEvent)
        |
        v
  Event queue  -->  Event loop (EDT)
                          |
                          v
                 Listener -> Handler
                          |
                          v
        GUI update (status label + event log)
```

---

## Part 5: Potential Issues
1. A slow handler, such as a network call to a real thermostat, would freeze the interface - run slow work on a background thread and return to the EDT only to update the display.
2. Several sources may change the same state at nearly the same time, such as a timer and a user both toggling the lights - keep all state changes on the EDT so they are handled one at a time.
3. A missed or duplicated event, such as a door sensor that bounces - ignore repeated identical events within a short window and always log each accepted event.
