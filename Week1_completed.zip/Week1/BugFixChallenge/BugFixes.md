# Bug Fix Documentation

## Bug 1: Blocking the EDT
- **Symptom:** The window froze for five seconds after clicking Process. It could not be moved, and the label did not repaint until the sleep ended.
- **Cause:** `Thread.sleep(5000)` ran inside the ActionListener, which executes on the Event Dispatch Thread. While the EDT slept it could not process repaint or input events.
- **Fix:** The long task now runs in a new background thread. The button is disabled while it works.
- **Code Change:** Wrapped the sleep in `new Thread(() -> { ... }).start()` and moved the final `statusLabel.setText("Done!")` into `SwingUtilities.invokeLater(...)`.

## Bug 2: Missing Listener
- **Symptom:** Clicking Increment did nothing and the count stayed at 0.
- **Cause:** The button was created and added to the frame, but no ActionListener was registered, so the click event had no handler.
- **Fix:** Added an ActionListener to the increment button.
- **Code Change:** Added `incrementButton.addActionListener(e -> { count++; countLabel.setText("Count: " + count); });`.

## Bug 3: Wrong Thread
- **Symptom:** The clock label could update erratically or fail to repaint, and Swing's thread rules were being violated.
- **Cause:** The background thread called `timeLabel.setText(...)` directly. Swing components are not thread-safe and must only be touched from the EDT.
- **Fix:** The background thread still sleeps and loops, but the label update is handed to the EDT.
- **Code Change:** Replaced the direct call with `SwingUtilities.invokeLater(() -> timeLabel.setText(now));` and made the `running` flag `volatile` so the loop sees changes made from other threads.

## Bug 4: Memory Leak
- **Symptom:** Memory use kept growing after buttons were added and removed.
- **Cause:** "Remove All" removed the buttons from the panel, but `createdButtons` still held a reference to every one of them, so the garbage collector could not free them. The button numbering also kept counting up from the stale list.
- **Fix:** Clear the list at the same time as the panel.
- **Code Change:** Added `createdButtons.clear();` before `buttonPanel.removeAll();` in the Remove All listener.
